const payment = (prefix) => { 
	return `• *PAYMENT*
*GOPAY :* ${gopay}
*DANA :* ${dana}
*OVO :* ${ovo}
*PULSA :* ${pulsa}
*QRIS :* ${linkqris}
*SAWERIA :* ${saweria}
*LINK TREE :* ${linktree}
*MINAT HUBUNGI : ${nomorowner}
`
}

exports.payment = payment