const topuppointblank = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
*LIST TOPUP PB*
*NO ILEGAL*
_tidak tersedia, ke Indomaret Sono_
`
}

exports.topuppointblank = topuppointblank