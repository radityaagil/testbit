const topupsaldo = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
• ${prefix}topupgopay
• ${prefix}topupdana
• ${prefix}topupovo
• ${prefix}topuppulsa
`
}

exports.topupsaldo = topupsaldo