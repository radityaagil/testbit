const storemenu = (prefix) => { 
	return `*HALLO KAK👋*
*MAU BELI APA KAK? PILIH DIBAWAH YA!!!*
• ${prefix}topupgame
• ${prefix}topupsaldo
`
}

exports.storemenu = storemenu