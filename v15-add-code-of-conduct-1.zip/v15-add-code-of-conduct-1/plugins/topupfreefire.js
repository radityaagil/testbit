const topupfreefire = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
*LIST DM FF*
*NO ILEGAL 100%*
5.500 = 20💎
9.500 = 50💎
11.500 = 70💎
17.500 = 100💎
21.500 = 140💎
32.500 = 210💎
52.500 = 355💎
77.500 = 510💎
105.300 = 720💎
205.300 = 1450💎
311.200 = 2180💎
510.600 = 3640💎
1.050.100 = 17280💎
*MM* : 29.300
*MB*  : 141.600
*minat? hub :* http://wa.me/${nomorowner}
`
}

exports.topupfreefire = topupfreefire