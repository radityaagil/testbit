const topupgame = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
• ${prefix}topupfreefire
• ${prefix}topupmobilelegends
• ${prefix}topuppubg
• ${prefix}topuppointblank
`
}

exports.topupgame = topupgame