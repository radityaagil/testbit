//link : https://api-danzz.herokuapp.com
//apikey : Ramdaniofficial
//mohon maap apabila menemukan bug di apikey tersebut, mohon di maklumi.